/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package citasMedicasPkg;

/**
 *
 * @author diotallevi
 */
public abstract class Persona {
    
    private double cedula;
    private String nombre;
    private String genero;

    //constructor
    public Persona(double entradaCedula, String entradaNombre, String entradaGenero) {
        this.cedula = entradaCedula;
        this.nombre = entradaNombre;
        this.genero = entradaGenero;
    }
    
    
    //get y set
    public double getCedula() {
        return cedula;
    }

    public void setCedula(double cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
    
}
