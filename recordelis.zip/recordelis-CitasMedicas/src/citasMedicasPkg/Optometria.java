/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package citasMedicasPkg;

/**
 *
 * @author diotallevi
 */
public class Optometria extends Persona{
    
    private String licencia;
    private String fechaCita;
    
    public Optometria(double entradaCedula, String entradaNombre, String entradaGenero, String entradaLicenciaOptometra) {
        super(entradaCedula, entradaNombre, entradaGenero);
        
        this.licencia=entradaLicenciaOptometra;
    }

    public String getLicencia() {
        return licencia;
    }

    public void setLicencia(String licencia) {
        this.licencia = licencia;
    }

    public String getFechaCita() {
        return fechaCita;
    }

    public void setFechaCita(String fechaCita) {
        this.fechaCita = fechaCita;
    } 
    
}
