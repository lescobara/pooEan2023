/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package citasMedicasPkg;

/**
 *
 * @author diotallevi
 */
public class MedicoEspecialista extends MedicoGral{
    
    private String nombreEspecialidad;
    
    public MedicoEspecialista(double entradaCedula, String entradaNombre, String entradaGenero, 
            String entradaLicencia,String entradaNombreEspecialidad) {
        super(entradaCedula, entradaNombre, entradaGenero, entradaLicencia);
        this.nombreEspecialidad=entradaNombreEspecialidad;
    }

    public String getNombreEspecialidad() {
        return nombreEspecialidad;
    }

    public void setNombreEspecialidad(String nombreEspecialidad) {
        this.nombreEspecialidad = nombreEspecialidad;
    }  
}
