package citasMedicasPkg;

import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author diotallevi
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        MedicoGral objetoMedico1=new MedicoGral(1234,"Fernando Castro","masculino","abc123");
        MedicoEspecialista objetoEspecialista1=new MedicoEspecialista(4567,"Patricia Soto","femenino","xyz34","Pediatria");
        Optometria objetoOptometria=new Optometria(987,"Luis Pérez","masculino","mkd34");
        
        Paciente objetoPaciente=new Paciente(4556,"Sofia Henao","femenino");
        
        System.out.println("Que tipo de cita desea agendar: 1. General 2. Especialista 3. optometra");
        Scanner objetoScanner=new Scanner(System.in);
        int opcion=objetoScanner.nextInt();
        
        if (opcion==1){
            objetoPaciente.generarCita(objetoMedico1, "2023-11-04");
        }else if (opcion==2){
            objetoPaciente.generarCita(objetoEspecialista1,"2023-16-05");
        }else if (opcion==3){
            objetoPaciente.generarCita(objetoOptometria, "2023-13-04");
        }
    }
    
}
