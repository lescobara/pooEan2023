/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package citasMedicasPkg;

/**
 *
 * @author diotallevi
 */
public class Paciente extends Persona{
    
    public Paciente(double entradaCedula, String entradaNombre, String entradaGenero) {
        super(entradaCedula, entradaNombre, entradaGenero);
    }   
    
    /*para crear una cita necesito los datos del profesional y la fecha*/
    
    //empleando polomorfismo por mensaje puedo cargar los distintos tipos de objetos
    //con su respectivo profesional
    public void generarCita(MedicoGral objetoEntradaMedico,String entradaFechaCita){
        System.out.println ("se generó cita con el médico General");
        System.out.println ("Nombre Médico general"+objetoEntradaMedico.getNombre());
        System.out.println("Fecha"+entradaFechaCita);
    
    }
    
    public void generarCita(MedicoEspecialista objetoEntradaMedicoEspecialista,String entradaFechaCita){
        System.out.println ("se generó cita con el médico Especialista");
        System.out.println ("Nombre Médico general"+objetoEntradaMedicoEspecialista.getNombre());


    }
    
    public void generarCita(Optometria objetoOptometriaEntrada,String entradaFecha){
        System.out.println("See generó cita con el optómetra");
    
    }
}
